#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

//structure holding image link and details going along with it
typedef struct image{
  char* name;
  char* Hint1;
  char* Hint2;
  char* Hint3;
  char* File_name;
  int length;
}image;

int get_random();
void display(image* A);
void loss(image* A);
int play(image* A);

int main(void) {
  //Introducing user
  printf("Hello, and welcome to Aaron's Word Guessing Game! \n");
  printf("There are over 14 different words with hints for you to guess!\n");
  printf("The standard mode I created generates a random number and that determines what image is chosen for our game,\nbut if you would like, you can manually choose the image you want to use.\n");
  
  //getting user's choice
  int choice1;
  printf("What would you like to do?\n1.Random Image\n2.Choose an Image\n");
  scanf("%d", &choice1);

  //repeating until they put in a good number
  while(choice1 != 1 && choice1!=2){
    printf("Invalid input, please put enter your choice of either a 1 or a 2\n");
    scanf("%d", &choice1);
  }
  //declaring image number depending on choice
  int image_num = 0;
  if(choice1==1){
    printf("Great, you have chosen to have a random image!");
    image_num = get_random();
  }
  if(choice1 ==2){
    printf("Great, you have chosen to choose your own image!\n");
    printf("Each image has its own number to represent it, starting at 0 and ending at 13.\nPlease type in one of these numbers\n");
    scanf("%d", &image_num);

    while(image_num <0 || image_num >13){
      printf("Invalid input, please try again. Remember, your image number must be from 0-11\n");
      scanf("%d", &image_num);
    }
  }
  //Making an object to hold all the image information that's relevant
  image* A = (image*)malloc(sizeof(image));

  switch(image_num){
    //declaring parts of the object depending on what the item was
    case 0: ;
            A->length = 10;
            A->name = (char*)malloc(sizeof(char) * 11);
            A->name = "james_bond";

            A->Hint1 = (char*)malloc(sizeof(char) * 94);
            A->Hint1 = "(2 words, 10 characters)This fictional character has been portrayed by 12 actors in 26 movies";

            A->Hint2 = (char*)malloc(sizeof(char) * 40);
            A->Hint2 = "This person is linked to the number 007";

            A->Hint3 = (char*)malloc(sizeof(char) * 55);
            A->Hint3 = "This British MI6 agent was last played by Sean Connery";

            A->File_name = (char*)malloc(sizeof(char) * 10);
            A->File_name = "james_bond.txt";
            break;
    case 1: ;
            A->length = 5;
            A->name = (char*)malloc(sizeof(char) * 6);
            A->name = "apple";

            A->Hint1 = (char*)malloc(sizeof(char) * 45);
            A->Hint1 = "(1 word, 5 characters)This object is a fruit";

            A->Hint2 = (char*)malloc(sizeof(char) * 35);
            A->Hint2 = "A famous company is named after it";

            A->Hint3 = (char*)malloc(sizeof(char) * 41);
            A->Hint3 = "One of these a day keeps the doctor away";

            A->File_name = (char*)malloc(sizeof(char) * 10);
            A->File_name = "apple.txt";
            break;
    case 2: ;
            A->length = 4;
            A->name = (char*)malloc(sizeof(char) * 5);
            A->name = "cake";

            A->Hint1 = (char*)malloc(sizeof(char) * 78);
            A->Hint1 = "(1 word, 4 characters)This object is a famous food that revolves around flour";

            A->Hint2 = (char*)malloc(sizeof(char) * 38);
            A->Hint2 = "Miniature versions of this food exist";

            A->Hint3 = (char*)malloc(sizeof(char) * 45);
            A->Hint3 = "You typically eat this food on your birthday";

            A->File_name = (char*)malloc(sizeof(char) * 9);
            A->File_name = "cake.txt";
            break;
    case 3: ;
            A->length = 9;
            A->name = (char*)malloc(sizeof(char) * 10);
            A->name = "fireplace";

            A->Hint1 = (char*)malloc(sizeof(char) * 94);
            A->Hint1 = "(1 word, 9 characters) One of these was more common before modern day heaters were introduced";

            A->Hint2 = (char*)malloc(sizeof(char) * 42);
            A->Hint2 = "This object can be made of metal or brick";

            A->Hint3 = (char*)malloc(sizeof(char) * 64);
            A->Hint3 = "Santa Claus passes through the chimney connected to this object";

            A->File_name = (char*)malloc(sizeof(char) * 14);
            A->File_name = "fireplace.txt";
            break;
    case 4: ;
            A->length = 7;
            A->name = (char*)malloc(sizeof(char) * 8);
            A->name = "gameboy";

            A->Hint1 = (char*)malloc(sizeof(char) * 113);
            A->Hint1 = "(1 word, 7 characters) This game system featured hits like 'Pokemon Yellow', 'Metroid 2', and 'Super Mario Land'";

            A->Hint2 = (char*)malloc(sizeof(char) * 52);
            A->Hint2 = "This Nintendo-made game system was released in 1989";

            A->Hint3 = (char*)malloc(sizeof(char) * 46);
            A->Hint3 = "This was the first major handheld game system";

            A->File_name = (char*)malloc(sizeof(char) * 12);
            A->File_name = "gameboy.txt";
            break;
    case 5: ;
            A->length = 6;
            A->name = (char*)malloc(sizeof(char) * 7);
            A->name = "gotham";

            A->Hint1 = (char*)malloc(sizeof(char) * 75);
            A->Hint1 = "(1 word, 6 characters) This fictional city exists in the DC comic universe";

            A->Hint2 = (char*)malloc(sizeof(char) * 60);
            A->Hint2 = "Jim Gordon presides as the police commissioner of this city";

            A->Hint3 = (char*)malloc(sizeof(char) * 41);
            A->Hint3 = "This city is the one that Batman defends";

            A->File_name = (char*)malloc(sizeof(char) * 11);
            A->File_name = "gotham.txt";
            break;
    case 6: ;
            A->length = 6;
            A->name = (char*)malloc(sizeof(char) * 7);
            A->name = "laptop";

            A->Hint1 = (char*)malloc(sizeof(char) * 91);
            A->Hint1 = "(1 word, 6 characters) This technological invention was first made by Adam Osborne in 1981";

            A->Hint2 = (char*)malloc(sizeof(char) * 75);
            A->Hint2 = "Some notable companies that make this product are Apple, Microsoft, and HP";

            A->Hint3 = (char*)malloc(sizeof(char) * 46);
            A->Hint3 = "What is another word for a portable computer?";

            A->File_name = (char*)malloc(sizeof(char) * 11);
            A->File_name = "laptop.txt";
            break;
    case 7: ;
            A->length = 10;
            A->name = (char*)malloc(sizeof(char) * 11);
            A->name = "leprechaun";

            A->Hint1 = (char*)malloc(sizeof(char) * 63);
            A->Hint1 = "(1 word, 10 characters) This fictional being has Irish origins";

            A->Hint2 = (char*)malloc(sizeof(char) * 61);
            A->Hint2 = "Typically this being is portrayed as short and wearing green";

            A->Hint3 = (char*)malloc(sizeof(char) * 51);
            A->Hint3 = "The mascot of Lucky Charms represents one of these";

            A->File_name = (char*)malloc(sizeof(char) * 15);
            A->File_name = "leprechaun.txt";
            break;
    case 8: ;
            A->length = 6;
            A->name = (char*)malloc(sizeof(char) * 7);
            A->name = "pacman";

            A->Hint1 = (char*)malloc(sizeof(char) * 67);
            A->Hint1 = "(1 word, 6 characters) This character was created by Toru Iwatani";

            A->Hint2 = (char*)malloc(sizeof(char) * 56);
            A->Hint2 = "A famous boxer's nickname corresponds to this character";

            A->Hint3 = (char*)malloc(sizeof(char) * 51);
            A->Hint3 = "This yellow character created in 1980 lives to eat";

            A->File_name = (char*)malloc(sizeof(char) * 11);
            A->File_name = "pacman.txt";
            break;
    case 9: ;
            A->length = 5;
            A->name = (char*)malloc(sizeof(char) * 6);
            A->name = "pepsi";

            A->Hint1 = (char*)malloc(sizeof(char) * 90);
            A->Hint1 = "(1 word, 5 characters) This brand featured Cindy Crawford in their famous 1992 commercial";

            A->Hint2 = (char*)malloc(sizeof(char) * 50);
            A->Hint2 = "This brand owns Mountain Dew, Aquafina, and Brisk";

            A->Hint3 = (char*)malloc(sizeof(char) * 67);
            A->Hint3 = "This brand is the primary rival of Coke in the soft drink industry";

            A->File_name = (char*)malloc(sizeof(char) * 10);
            A->File_name = "pepsi.txt";
            break;
    case 10:;
            A->length = 8;
            A->name = (char*)malloc(sizeof(char) * 9);
            A->name = "princess";

            A->Hint1 = (char*)malloc(sizeof(char) * 78);
            A->Hint1 = "(1 word, 8 characters) Disney commonly portrays these females in their movies";

            A->Hint2 = (char*)malloc(sizeof(char) * 61);
            A->Hint2 = "The video game character Mario is always saving one of these";

            A->Hint3 = (char*)malloc(sizeof(char) * 47);
            A->Hint3 = "Before you are a queen, you must be this first";

            A->File_name = (char*)malloc(sizeof(char) * 13);
            A->File_name = "princess.txt";
            break;
    case 11:;
            A->length = 9;
            A->name = (char*)malloc(sizeof(char) * 10);
            A->name = "snowflake";

            A->Hint1 = (char*)malloc(sizeof(char) * 52);
            A->Hint1 = "(1 word, 9 characters) No two of these are the same";

            A->Hint2 = (char*)malloc(sizeof(char) * 30);
            A->Hint2 = "Each one of these has 6 sides";

            A->Hint3 = (char*)malloc(sizeof(char) * 52);
            A->Hint3 = "You are likely to find one of these on a winter day";

            A->File_name = (char*)malloc(sizeof(char) * 14);
            A->File_name = "snowflake.txt";
            break; 
    case 12:;
            A->length = 5;
            A->name = (char*)malloc(sizeof(char) * 6);
            A->name = "t-rex";

            A->Hint1 = (char*)malloc(sizeof(char) * 63);
            A->Hint1 = "(1 hyphenated word, 5 characters) This creature is carnivorous";

            A->Hint2 = (char*)malloc(sizeof(char) * 63);
            A->Hint2 = "This creature was at the top of the food chain during its time";

            A->Hint3 = (char*)malloc(sizeof(char) * 46);
            A->Hint3 = "This creature is notorious for its short arms";

            A->File_name = (char*)malloc(sizeof(char) * 13);
            A->File_name = "t-rex.txt";
            break; 
    case 13:;
            A->length = 8;
            A->name = (char*)malloc(sizeof(char) * 9);
            A->name = "umbrella";

            A->Hint1 = (char*)malloc(sizeof(char) * 77);
            A->Hint1 = "(1 word, 8 characters) Basic versions of this can be traced back 4,000 years";

            A->Hint2 = (char*)malloc(sizeof(char) * 56);
            A->Hint2 = "Rihanna recorded a hit single about this object in 2008";

            A->Hint3 = (char*)malloc(sizeof(char) * 34);
            A->Hint3 = "You would use this on a rainy day";

            A->File_name = (char*)malloc(sizeof(char) * 13);
            A->File_name = "umbrella.txt";
            break; 

    default: break;
  }
  play(A);
  printf("\n\nThank you for playing Aaron's Word Guessing Game!\nSpecial Thanks to  http://www.ascii-art.de/ for providing the art for the pictures when you won.\nThis work is non-commercial, and I am allowed to use these pictures as fair use, as long as I cite the authors.\nOnce again thank you, and have a great day!");



  return 0;
}

int play(image* A){
  printf("\n\nYou will get three tries to guess the word that either you or the program chose. After each entry, you will\nget back a score which tells you how many characters were in the right position in your guess.\nIf your guess was too long, 1 point is automatically deducted. Please make sure each of your guesses is lowercase\nso that the Strings can be compared properly. Also, when applicable, use a '_' to indicate a space. You will get\nthree guesses. Good Luck!\n");
  int tries = 1;
  //Making an array to hold the user's input
  char B[A->length + 1];
  //limiting the user to three tries and setting the hints for each time
  while(tries <= 3){
    int score = -1;
    if(tries == 1){
      printf("\nHINT 1: %s\n", A->Hint1);
    }
    if(tries ==2){
      printf("\nHINT 2: %s\n", A->Hint2);
    }
    if(tries == 3){
      printf("\nHINT 3: %s\n", A->Hint3);
    }
    printf("Please enter your guess\n");
    scanf("%s", B);
    for(int i = 0; i<A->length + 1; i++){
      if(A->name[i]==B[i]){
        score++;
      }
    }
    printf("\nYour score was %d\n", score);
    if(score>=A->length){
      display(A);
      break;
    }
  tries++;
  }
  if(tries >=4){
    loss(A);
  }
  return 0;
}

void display(image* A){
  printf("Congrats on guessing the word!\n Here is a picture of it: \n");
  //opening file and printing it out
  FILE* fp = fopen(A->File_name, "r");
  char str[200];
  while(fgets(str, 200, fp)!=NULL){
    printf("%s",  str);
  }
}
void loss(image* A){
  printf("The word you were trying to guess was %s", A->name);
  printf("\nWell, not everyone can be a winner, but don't give up! Michael Jordan was cut from his high school baskeball team! Just keep practicing and you'll get it one day!");
}

//Made random method if the user chose to get a random
int get_random(){
  time_t t;
  srand((unsigned) time(&t)); 
  int low = 0; 
  int high = 13;
  int num = (rand() % (high - low  + 1)) + low;
  return num;
}
